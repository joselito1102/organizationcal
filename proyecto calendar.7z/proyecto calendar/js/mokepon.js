//iniciar juego
const sectionSeleccionarAtaque = document.getElementById('seleccionar-ataque')
const sectionReiniciar = document.getElementById('reiniciar')
const botonMascotaJugador = document.getElementById('boton-mascota')
const botonReiniciar = document.getElementById('boton-reiniciar')


//seleccionar mascota jugador
const sectionSeleccionarMascota = document.getElementById('seleccionar-mascota')

const spanMascotaJugador = document.getElementById('mascota-jugador')

//seleccionar mascota enemigo
const spanMascotaEnemigo = document.getElementById('mascota-enemigo')

//combate
const spanVidasJugador = document.getElementById('vidas-jugador')
const spanVidasEnemigo = document.getElementById('vidas-enemigo')

// crear mensaje
const sectionMensajes = document.getElementById('resultado')
const ataquesDelJugador = document.getElementById('ataques-Del-Jugador')
const ataquesDelEnemigo = document.getElementById('ataques-Del-Enemigo')
const contenedorTarjetas = document.getElementById('contenedorTarjetas')

const contenedorAtaques = document.getElementById('contenedorAtaques')

//variable global
let mokepones = []
let ataqueJugador = []
let ataqueEnemigo = []
let opcionDeMokepones
let inputPIPLUP 
let inputHOPPOTOM 
let inputINFERNAPE 
let mascotaJugador
let ataquesMokepon
let botonFuego 
let botonAgua 
let botonTierra 
let indexAtaqueJugador;
let indexAtaqueEnemigo;
let botones = []
let vidasJugador = 3
let vidasEnemigo = 3

class Mokepon {
    constructor(nombre, foto, vida){
        // clase misma
        this.nombre = nombre
        this.foto = foto
        this.vida = vida
        this.ataques = []
                                   
    }

}

let PIPLUP = new Mokepon('PIPLUP', './imagenescss/descarga.png', 5)
let HOPPOTOM = new Mokepon('HOPPOTOM','./imagenescss/Gengar.png',5)
let INFERNAPE = new Mokepon('INFERNAPE','./imagenescss/lucario.png',5)

//inyecta valores al arreglo
//mokepones.push(PIPLUP,HOPPOTOM,INFERNAPE)

PIPLUP.ataques.push(
    { nombre: '💧', id: 'boton-agua'},
    { nombre: '💧', id: 'boton-agua'},
    { nombre: '💧', id: 'boton-agua'},
    { nombre: '🔥', id: 'boton-fuego'},
    { nombre: '🌿', id: 'boton-tierra'},
)


HOPPOTOM.ataques.push(

    { nombre: '🌿', id: 'boton-tierra'},
    { nombre: '🌿', id: 'boton-tierra'},
    { nombre: '🌿', id: 'boton-tierra'},
    { nombre: '💧', id: 'boton-agua'},
    { nombre: '🔥', id: 'boton-fuego'},
    
)


INFERNAPE.ataques.push(
    { nombre: '🔥', id: 'boton-fuego'},
    { nombre: '🔥', id: 'boton-fuego'},
    { nombre: '🔥', id: 'boton-fuego'},
    { nombre: '💧', id: 'boton-agua'},
    { nombre: '🌿', id: 'boton-tierra'}
)

mokepones.push(PIPLUP,HOPPOTOM,INFERNAPE)

//mapear errores
/*console.log(PIPLUP)*/

function iniciarJuego(){
    
    sectionSeleccionarAtaque.style.display = 'none' 
    // forma para escribir html
    mokepones.forEach((mokepon)=>{
        opcionDeMokepones = `
        <input type="radio" name = "mascota" id = ${mokepon.nombre} />
            <LABEL class="tarjeta-de-mokepon" for = ${mokepon.nombre} >
                <p>${mokepon.nombre} </p>
                <img src= ${mokepon.foto} alt=${mokepon.nombre} >
            </LABEL>
        `
    contenedorTarjetas.innerHTML += opcionDeMokepones

     inputPIPLUP = document.getElementById('PIPLUP')
     inputHOPPOTOM = document.getElementById('HOPPOTOM')
     inputINFERNAPE = document.getElementById('INFERNAPE')


    })

    sectionReiniciar.style.display = 'none'   
    botonMascotaJugador.addEventListener('click', seleccionarMascotaJugador)
    botonReiniciar.addEventListener('click', reiniciarJuego)

}


function seleccionarMascotaJugador(){
    sectionSeleccionarMascota.style.display = 'none'
    sectionSeleccionarAtaque.style.display = 'flex'
    //fuente de verdad
 if(inputPIPLUP.checked){
    spanMascotaJugador.innerHTML = inputPIPLUP.id
    mascotaJugador = inputPIPLUP.id
 }else if (inputHOPPOTOM.checked){
    spanMascotaJugador.innerHTML = inputHOPPOTOM.id
    mascotaJugador = inputHOPPOTOM.id
 }else if (inputINFERNAPE.checked){
    spanMascotaJugador.innerHTML = inputINFERNAPE.id
    mascotaJugador = inputINFERNAPE.id
 }else {
    alert("no has seleccionado ninguna mascota")
 }

 extraerAtaques(mascotaJugador)
 seleccionarMascotaEnemigo()

}

function extraerAtaques(mascotaJugador){
    let ataques
    for (let i = 0; i < mokepones.length; i++) {
        if (mascotaJugador == mokepones[i].nombre){
            ataques = mokepones[i].ataques
        }
        
    }
    mostrarAtaques(ataques)
}

function mostrarAtaques(ataques){
    ataques.forEach((ataques)=>{
        ataquesMokepon = `
        <button id = ${ataques.id} class="boton-de-ataque">${ataques.nombre}
        </button>
        `
        contenedorAtaques.innerHTML += ataquesMokepon
    })

    botonFuego = document.getElementById('boton-fuego')
    botonAgua = document.getElementById('boton-agua')
    botonTierra = document.getElementById('boton-tierra')
    botones = document.querySelectorAll('.BAtaque')

  

}
function secuenciaAtaque() {
    botones.forEach((boton) => {
        boton.addEventListener('click', (e) => {
            if (e.target.textContent === '🔥') {
                ataqueJugador.push('FUEGO')
                console.log(ataqueJugador)
                boton.style.background = '#112f58'   
            } else if (e.target.textContent === '💧') {
                ataqueJugador.push('AGUA')
                console.log(ataqueJugador)
                boton.style.background = '#112f58'
            } else {
                ataqueJugador.push('TIERRA')
                console.log(ataqueJugador)
                boton.style.background = '#112f58'
            }
            ataqueAleatorioEnemigo()
        })
    })

}

function seleccionarMascotaEnemigo(){
    let mascotaAleatorio = aleatorio(0,mokepones.length -1)
    //escoger un elemento, con el nombre y con el innerhtml que liga el id del elemento html
    spanMascotaEnemigo.innerHTML = mokepones[mascotaAleatorio].nombre
    ataquesMokeponEnemigo = mokepones[mascotaAleatoria].ataques
   secuenciaAtaque()
}




function ataqueAleatorioEnemigo() {
    let ataqueAleatorio = aleatorio(0,ataquesMokeponEnemigo.length -1)
    
    if (ataqueAleatorio == 0 || ataqueAleatorio ==1) {
        ataqueEnemigo.push('FUEGO')
    } else if (ataqueAleatorio == 3 || ataqueAleatorio == 4) {
        ataqueEnemigo.push('AGUA')
    } else {
        ataqueEnemigo.push('TIERRA')
    }
    console.log(ataqueEnemigo)
    iniciarPelea()
}

function iniciarPelea() {
    if (ataqueJugador.length === 5) {
        combate();
    }
}


function indexAmbosOponente(jugador, enemigo) {
    indexAtaqueJugador = ataqueJugador[jugador];
    indexAtaqueEnemigo = ataqueEnemigo[enemigo];
}

function combate(){
   

    for (let index = 0; index < ataqueJugador.length; index++) {
        if(ataqueJugador[index] === ataqueEnemigo[index]) {
            indexAmbosOponente(index, index)
            crearMensaje("EMPATE")
        }
    }

    revisarVidas()
}


function revisarVidas(){
    if(vidasEnemigo == 0){
        crearMensajeFinal('FELICITACIONES GANASTE :)')
    }else if(vidasJugador == 0){
        crearMensajeFinal('LO SIENTO PERDISTE :(')
    }
}

function crearMensaje(resultado){ 
    
    let nuevoAtaqueDelJugador = document.createElement('p')
    let nuevoAtaqueDelEnemigo = document.createElement('p')

    sectionMensajes.innerHTML = resultado
    nuevoAtaqueDelJugador.innerHTML = indexAtaqueJugador;
    nuevoAtaqueDelEnemigo.innerHTML = indexAtaqueEnemigo;

    
    ataquesDelJugador.appendChild(nuevoAtaqueDelJugador)
    ataquesDelEnemigo.appendChild(nuevoAtaqueDelEnemigo)
   
}
function crearMensajeFinal(resultadoFinal){

    sectionMensajes.innerHTML = resultadoFinal
    botonFuego.disabled = true
    botonAgua.disabled = true
    botonTierra.disabled = true
    sectionReiniciar.style.display = 'block'

}

function reiniciarJuego(){
    location.reload()
}

function aleatorio(min, max){
    return Math.floor(Math.random() * (max-min+1)+min)
}


window.addEventListener('load', iniciarJuego)

